//LUANA MONTEIRO e LUAN MARQUETI

package com.example.apiMecanico.conserto;

import org.springframework.data.jpa.repository.JpaRepository;
public interface ConsertoRepository  extends JpaRepository<Conserto, Long> {
}
