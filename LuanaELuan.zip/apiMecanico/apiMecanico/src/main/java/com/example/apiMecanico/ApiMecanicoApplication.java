//LUANA MONTEIRO e LUAN MARQUETI

package com.example.apiMecanico;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiMecanicoApplication {

	public static void main(String[] args) {

		SpringApplication.run(ApiMecanicoApplication.class, args);
	}



}
