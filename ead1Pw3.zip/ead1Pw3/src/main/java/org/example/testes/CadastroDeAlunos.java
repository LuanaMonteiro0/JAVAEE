//Nomes: Luan marqueti, Luana Monteiro

package org.example.testes;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import org.example.dao.AlunoDAO;
import org.example.modelo.Aluno;
import org.example.util.JPAUtil;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;

import java.math.BigDecimal;
import java.util.Scanner;

@SpringBootApplication
public class CadastroDeAlunos {

    public static void main(String[] args) {

        SpringApplication.run(CadastroDeAlunos.class, args);

        int opcao = -1;
        Scanner leitor = new Scanner(System.in);
        //EntityManager em = JPAUtil.getEntityManager();

        EntityManagerFactory factory = Persistence.createEntityManagerFactory("ead1Pw3");
        EntityManager em = factory.createEntityManager();

        AlunoDAO alunoDAO = new AlunoDAO(em);

        do {
            exibirMenu();
            System.out.print("Digite a opção desejada: ");
            opcao = leitor.nextInt();
            switch (opcao) {
                case 1:
                    Aluno a = criarAluno();
                    em.getTransaction().begin();
                    alunoDAO.cadastrarAluno(a);
                    em.getTransaction().commit();
                    System.out.println("Aluno cadastrado");
                    break;
                case 2:
                    Scanner scanner1 = new Scanner(System.in);
                    System.out.print("Digite o nome do aluno: ");
                    String nome = scanner1.nextLine();
                    Aluno b = alunoDAO.buscarAlunoPeloNome(nome);
                    if (b != null) {
                        em.getTransaction().begin();
                        alunoDAO.excluirAluno(b);
                        em.getTransaction().commit();
                        System.out.println("Aluno(a) excluído(a) com sucesso!");
                    } else {
                        System.out.println("Nome não consta no sistema.");
                    }
                    break;
                case 3:
                    Scanner scanner2 = new Scanner(System.in);
                    System.out.print("Digite o nome do aluno: ");
                    String nome2 = scanner2.nextLine();
                    Aluno c = alunoDAO.buscarAlunoPeloNome(nome2);
                    if (c != null) {
                        em.getTransaction().begin();
                        alunoDAO.alterarAluno(c);
                        em.getTransaction().commit();
                        System.out.println("Aluno(a) alterado(a) com sucesso!");
                    } else {
                        System.out.println("Nome não consta no sistema.");
                    }
                    break;
                case 4:
                    Scanner scanner3 = new Scanner(System.in);
                    System.out.print("Digite o nome do aluno: ");
                    String nome3 = scanner3.nextLine();
                    Aluno d = alunoDAO.buscarAlunoPeloNome(nome3);
                    if (d != null) {
                        d.exibirDados();
                    } else {
                        System.out.println("Nome não consta no sistema.");
                    }
                    break;
                case 5:
                    alunoDAO.listarAlunos();
                    break;
                case 6:
                    alunoDAO.listarAlunosComStatusAprovado();
                    break;
                case 7:
                    break;
                default:
                    System.out.println("Opção Inválida");
                    break;
            }

        }
        while(opcao != 7);
        System.exit(0);
    }

    public static void exibirMenu() {
        System.out.println("\n** CADASTRO DE ALUNOS **\n");
        System.out.println("1 - Cadastrar aluno");
        System.out.println("2 - Excluir aluno");
        System.out.println("3 - Alterar aluno");
        System.out.println("4 - Buscar aluno pelo nome");
        System.out.println("5 - Listar todos os alunos");
        System.out.println("6 - Listar alunos (com status aprovação)");
        System.out.println("7 - FIM");
    }

    public static Aluno criarAluno() {

        Scanner leitor = new Scanner(System.in);
        Aluno a = new Aluno();
        System.out.println("Dados do Aluno:");
        System.out.print("Digite o nome: ");
        a.setNome(leitor.nextLine());
        System.out.print("Digite o ra: ");
        a.setRa(leitor.nextLine());
        System.out.print("Digite o email: ");
        a.setEmail(leitor.nextLine());
        System.out.print("Digite o nota1: ");
        a.setNota1(leitor.nextBigDecimal());
        System.out.print("Digite o nota2: ");
        a.setNota2(leitor.nextBigDecimal());
        System.out.print("Digite o nota3: ");
        a.setNota3(leitor.nextBigDecimal());

        return a;

    }
}