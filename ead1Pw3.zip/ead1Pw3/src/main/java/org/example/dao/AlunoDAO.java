//Nomes: Luan marqueti, Luana Monteiro

package org.example.dao;

import jakarta.persistence.EntityManager;
import jakarta.persistence.NoResultException;
import org.example.modelo.Aluno;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class AlunoDAO {

    private EntityManager em;

    public AlunoDAO(EntityManager em) {
        this.em = em;
    }

    public void cadastrarAluno(Aluno aluno) {
        this.em.persist(aluno);
    }

    public void excluirAluno(Aluno aluno) {
        this.em.remove(aluno);
    }

    public void alterarAluno(Aluno a) {

        a.exibirDados();
        Scanner leitor = new Scanner(System.in);
        System.out.println("Novos dados");
        System.out.print("Digite o nome: ");
        a.setNome(leitor.nextLine());
        System.out.print("Digite o ra: ");
        a.setRa(leitor.nextLine());
        System.out.print("Digite o email: ");
        a.setEmail(leitor.nextLine());
        System.out.print("Digite o nota1: ");
        a.setNota1(leitor.nextBigDecimal());
        System.out.print("Digite o nota2: ");
        a.setNota2(leitor.nextBigDecimal());
        System.out.print("Digite o nota3: ");
        a.setNota3(leitor.nextBigDecimal());

    }

    public Aluno buscarAlunoPeloNome(String nome) {
        String dados = "SELECT a FROM Aluno a WHERE a.nome = :nomeAluno";
        try {
            return this.em.createQuery(dados, Aluno.class).setParameter("nomeAluno", nome).getSingleResult();
        } catch (NoResultException e) {
            return null;
        }

    }

    public void listarAlunosComStatusAprovado() {

        String jpql = "SELECT a FROM Aluno a";
        List<Aluno> lista = new ArrayList<>();
        lista = this.em.createQuery(jpql, Aluno.class).getResultList();
        for (Aluno aluno : lista) {
            if (aluno.verificarSeAlunoFoiAprovado().compareTo("Situação: Aprovado") == 0) {
                aluno.exibirDados();
                aluno.exibirMedia();
                System.out.println(aluno.verificarSeAlunoFoiAprovado());
            }
        }

    }

    public void listarAlunos(){

        String jpql = "SELECT a FROM Aluno a";
        List<Aluno> lista = new ArrayList<>();
        lista = this.em.createQuery(jpql, Aluno.class).getResultList();
        for (Aluno aluno : lista) {
            aluno.exibirDados();
            aluno.exibirMedia();
            System.out.println(aluno.verificarSeAlunoFoiAprovado());;
        }

    }

}